main()
{
    printf ("%6$d\n", 6, 5, 4, 3, 2, 1);
}
