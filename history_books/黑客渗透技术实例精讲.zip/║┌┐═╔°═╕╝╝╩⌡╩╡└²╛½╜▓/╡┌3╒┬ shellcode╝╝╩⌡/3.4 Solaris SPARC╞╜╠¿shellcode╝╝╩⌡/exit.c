main()
{
    exit(0);
}
