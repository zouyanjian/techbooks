/* setuid.c
*
*  Learn AIX PowerPC assembly
*/
#include <unistd.h>
int main()
{
    setuid(0);
}
